public class MatriculaDTO {
    private int matriculaAluno;
    private int codDisciplina;

    public MatriculaDTO(int matriculaAluno, int codDisciplina) {
        this.matriculaAluno = matriculaAluno;
        this.codDisciplina = codDisciplina;
    }

    public int getMatriculaAluno() {
        return matriculaAluno;
    }

    public int getCodDisciplina() {
        return codDisciplina;
    }
}

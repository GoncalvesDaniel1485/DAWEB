import java.util.ArrayList;

public class AlunoController {
    private AlunoService service = new AlunoService();

    public void cadastrar(AlunoDTO dto) {
        try {
            service.cadastrar(dto);
            System.out.println("Aluno cadastrado com sucesso!");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void editar(AlunoDTO dto) {
        try {
            boolean ok = service.editar(dto);
            if (ok) System.out.println("Aluno atualizado com sucesso!");
            else    System.out.println("Aluno não encontrado.");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void matricular(MatriculaDTO dto, Disciplina d) {
        try {
            service.matricular(dto, d);
            System.out.println("Aluno matriculado na disciplina com sucesso!");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public Aluno buscar(int matricula) {
        return service.buscar(matricula);
    }

    public ArrayList<Aluno> listar() {
        return service.listar();
    }
}

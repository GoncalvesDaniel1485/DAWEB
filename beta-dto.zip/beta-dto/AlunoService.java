import java.util.ArrayList;

public class AlunoService {
    private AlunoRepository rep = new AlunoRepository();
    private ValidacaoService val = new ValidacaoService();

    public void cadastrar(AlunoDTO dto) {
        val.validarAluno(dto.getNome(), dto.getCpf(), dto.getIdade());
        rep.cadastrar(new Aluno(dto.getMatricula(), dto.getNome(), dto.getCpf(), dto.getIdade()));
    }

    public boolean editar(AlunoDTO dto) {
        val.validarAluno(dto.getNome(), dto.getCpf(), dto.getIdade());
        Aluno a = rep.buscarA(dto.getMatricula());
        if (a == null) return false;
        a.setNome(dto.getNome());
        a.setCpf(dto.getCpf());
        a.setIdade(dto.getIdade());
        return true;
    }

    public void matricular(MatriculaDTO dto, Disciplina d) {
        Aluno a = rep.buscarA(dto.getMatriculaAluno());
        if (a == null) throw new IllegalArgumentException("Aluno não encontrado.");
        a.adicionarDisciplina(d);
        d.adicionarAluno(a);
    }

    public Aluno buscar(int matricula) {
        return rep.buscarA(matricula);
    }

    public ArrayList<Aluno> listar() {
        return rep.getAlunos();
    }
}

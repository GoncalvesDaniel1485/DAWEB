public class AlunoDTO {
    private int matricula;
    private String nome;
    private String cpf;
    private int idade;

    public AlunoDTO(int matricula, String nome, String cpf, int idade) {
        this.matricula = matricula;
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
    }

    public int getMatricula() {
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public int getIdade() {
        return idade;
    }
}

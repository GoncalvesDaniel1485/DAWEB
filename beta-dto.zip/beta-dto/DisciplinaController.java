import java.util.ArrayList;

public class DisciplinaController {
    private DisciplinaService service = new DisciplinaService();

    public void cadastrar(DisciplinaDTO dto) {
        try {
            service.cadastrar(dto);
            System.out.println("Disciplina cadastrada com sucesso!");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public void editar(DisciplinaDTO dto) {
        try {
            boolean ok = service.editar(dto);
            if (ok) System.out.println("Disciplina atualizada com sucesso!");
            else    System.out.println("Disciplina não encontrada.");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public Disciplina buscar(int cod) {
        return service.buscar(cod);
    }

    public ArrayList<Disciplina> listar() {
        return service.listar();
    }
}

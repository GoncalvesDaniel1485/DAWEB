import java.util.ArrayList;

public class DisciplinaService {
    private DisciplinaRepository rep = new DisciplinaRepository();
    private ValidacaoService validator = new ValidacaoService();

    public void cadastrar(DisciplinaDTO dto) {
        validator.validarDisciplina(dto.getNome(), dto.getProfessor(), dto.getCurso());
        rep.cadastrar(new Disciplina(dto.getCod(), dto.getNome(), dto.getProfessor(), dto.getCurso()));
    }

    public boolean editar(DisciplinaDTO dto) {
        validator.validarDisciplina(dto.getNome(), dto.getProfessor(), dto.getCurso());
        Disciplina d = rep.buscarD(dto.getCod());
        if (d == null) return false;
        d.setNomeD(dto.getNome());
        d.setProfessor(dto.getProfessor());
        d.setCurso(dto.getCurso());
        return true;
    }

    public Disciplina buscar(int cod) {
        return rep.buscarD(cod);
    }

    public ArrayList<Disciplina> listar() {
        return rep.getDisciplinas();
    }
}
